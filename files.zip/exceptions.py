"""
exceptions.py - Exception hierarchy for the MDNS router.

Using a proper exception hierarchy instead of error callbacks means:
  - Errors propagate naturally up the call stack
  - Callers can catch specific errors and decide what to do
  - Code is testable (no sys.exit buried in library functions)
  - The router can skip a bad file rather than crashing the whole run
"""


class MDNSError(Exception):
    """Base class for all MDNS router errors."""


# ---------------------------------------------------------------------------
# File-level errors (can be caught per-file; router skips and continues)
# ---------------------------------------------------------------------------

class FileError(MDNSError):
    """A problem with a specific input file."""


class FileNotReadableError(FileError):
    """File cannot be opened or read."""


class UnrecognisedFormatError(FileError):
    """File header does not match any known format (U / P / T)."""


class BadFooterError(FileError):
    """Footer record is missing, has wrong line count, or wrong checksum."""


class BadChecksumError(BadFooterError):
    """Checksum mismatch (subclass so callers can choose to force-route)."""


# ---------------------------------------------------------------------------
# Routing errors
# ---------------------------------------------------------------------------

class RoutingError(MDNSError):
    """A routing or delivery operation failed."""


class NoRouteError(RoutingError):
    """No routing table entry matched the file."""


class DeliveryError(RoutingError):
    """File could not be delivered to its destination."""


# ---------------------------------------------------------------------------
# SFTP errors
# ---------------------------------------------------------------------------

class SFTPError(MDNSError):
    """An SFTP transport operation failed."""


class SFTPConnectionError(SFTPError):
    """Could not establish an SFTP connection."""


class SFTPAuthError(SFTPError):
    """SFTP authentication failed."""


class SFTPTransferError(SFTPError):
    """A file transfer (get/put/rename/delete) failed."""


# ---------------------------------------------------------------------------
# Configuration errors (fatal — raised at startup)
# ---------------------------------------------------------------------------

class ConfigError(MDNSError):
    """The configuration file is missing or contains errors."""


# ---------------------------------------------------------------------------
# Sequence file errors
# ---------------------------------------------------------------------------

class SequenceError(MDNSError):
    """The sequence file cannot be read or written."""

"""
router.py - File routing orchestrator.

Design improvements over v1
----------------------------
1.  `process_file()` is now a method on a `Router` class.  All
    shared resources (config, archive, sequences, logger) are
    injected once at construction time rather than passed as arguments
    to every function call.

2.  The method is decomposed into small, named private methods that
    each do one thing.  The happy path is easy to read at the top;
    error handling is isolated.

3.  Errors are exceptions — not return codes or callbacks.
    `process_file()` catches per-file errors and logs them; fatal
    errors (configuration, sequence file) propagate to the caller.

4.  The archive receives header parameters at archive time via the
    `StructuredFile.header` dataclass — no stored callback.

5.  `_open_sftp()` is a single method rather than duplicated logic
    in main.py.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path, PurePosixPath
from typing import Optional

from .config import RouterConfig, RouteEntry, matching_routes
from .structured_file import StructuredFile, FooterResult
from .archive import Archive
from .sequence import SequenceFile
from .sftp_util import SFTPConnection, open_sftp
from .netrc_util import find_machine, NetrcError
from .exceptions import (
    FileError, BadChecksumError, RoutingError,
    DeliveryError, SFTPError, SequenceError,
)
from . import file_util as _fu

log = logging.getLogger(__name__)


class Router:
    """
    Processes files from all configured input sources.

    Parameters
    ----------
    cfg      : fully-loaded :class:`RouterConfig`
    archive  : initialised :class:`Archive` for this run
    seq      : file-ID sequence counter (or None)
    name_seq : filename sequence counter (or None)
    """

    def __init__(
        self,
        cfg: RouterConfig,
        archive: Archive,
        seq: Optional[SequenceFile],
        name_seq: Optional[SequenceFile],
    ) -> None:
        self._cfg      = cfg
        self._archive  = archive
        self._seq      = seq
        self._name_seq = name_seq
        self._name_seq_used = False   # only advance once per file

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def process_file(
        self,
        file_path: str,
        allow_wildcard: bool,
    ) -> bool:
        """
        Process one file end-to-end.

        Returns True if the file was routed; False if skipped/unroutable.
        On per-file errors (bad format, bad footer) logs the problem
        and returns False so the router continues with the next file.
        """
        self._name_seq_used = False

        # -- Load --
        try:
            sf = StructuredFile.load(file_path)
        except FileError as exc:
            log.warning("Could not load %s: %s", file_path, exc)
            return False

        # -- Identify --
        try:
            sf.identify()
        except FileError as exc:
            log.warning("Cannot identify format of %s: %s", file_path, exc)
            return False

        log.info("Processing %s (format=%s)", file_path, sf.fmt)

        # -- Validate footer --
        try:
            footer = sf.validate()
        except FileError as exc:
            log.warning("Footer validation failed for %s: %s", file_path, exc)
            return False

        if footer == FooterResult.INVALID:
            log.warning("Bad footer: %s", file_path)
            return False

        # -- Harvest ACK data (no-op for non-ACK files) --
        sf.harvest_ack()

        # -- Route --
        routes = matching_routes(
            self._cfg,
            sf.header.file_type,
            sf.header.file_version,
            sf.header.dst_role,
            sf.header.dst_part,
            sf.header.test_flag,
            allow_wildcard,
        )

        routed = self._deliver_all(sf, routes, footer)

        # -- Archive (always, whether routed or not) --
        archive_path = self._archive.archive_file(file_path, sf.header)
        if routed:
            log.info("Routed and archived: %s → %s", file_path, archive_path)
        else:
            log.info("No route — archived: %s → %s", file_path, archive_path)

        return routed

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def _deliver_all(
        self,
        sf: StructuredFile,
        routes: list[RouteEntry],
        footer: FooterResult,
    ) -> bool:
        """Attempt delivery to every matching route entry."""
        if not routes:
            log.warning(
                "No route for %s %s %s %s %s",
                sf.header.file_type, sf.header.file_version,
                sf.header.dst_role, sf.header.dst_part,
                sf.header.test_flag or "----",
            )
            return False

        any_routed = False
        for route in routes:
            if route.is_inhibited:
                log.info("Route inhibited (%s) for %s", route.inhibit, sf.path)
                continue

            if footer == FooterResult.CHECKSUM_MISMATCH and not route.force_checksum:
                log.warning(
                    "Checksum mismatch and route is not force-enabled — "
                    "skipping %s", sf.path
                )
                continue

            try:
                self._deliver_one(sf, route)
                any_routed = True
            except (DeliveryError, SFTPError) as exc:
                log.error("Delivery failed for %s via %s: %s", sf.path, route, exc)

        return any_routed

    def _deliver_one(self, sf: StructuredFile, route: RouteEntry) -> None:
        """Deliver *sf* to a single *route* destination."""
        req_file_id = ""
        if sf.fmt == "P" and route.output_format != "P":
            if self._seq is None:
                raise DeliveryError(
                    "Pool promotion requires .SEQUENCE_FILE to be configured"
                )
            req_file_id = self._seq.get_next()

        lines = sf.render_lines(
            dst_fmt     = route.output_format,
            req_file_id = req_file_id,
            req_tflag   = route.test_flag,
            force_csum  = route.force_checksum,
        )
        content = "\n".join(lines) + "\n"

        if route.is_local:
            self._deliver_local(sf, route, content)
        elif route.is_sftp:
            self._deliver_sftp(sf, route, content)
        else:
            raise DeliveryError(f"Unknown transfer method {route.transfer_method!r}")

    # ------------------------------------------------------------------
    # Local delivery
    # ------------------------------------------------------------------

    def _deliver_local(
        self, sf: StructuredFile, route: RouteEntry, content: str
    ) -> None:
        """Write to intermediate dir then rename to final dir."""
        Path(route.intermediate_dir).mkdir(parents=True, exist_ok=True)
        int_path   = _fu.cat_filepath(route.intermediate_dir, sf.filename)
        final_path = _fu.cat_filepath(route.final_dest_dir,   sf.filename)

        try:
            Path(int_path).write_text(content, encoding="latin-1")
        except OSError as exc:
            raise DeliveryError(f"Cannot write {int_path}: {exc}") from exc

        # Apply chmod mask if configured
        if self._cfg.file_mask:
            try:
                os.chmod(int_path, _parse_octal_mode(self._cfg.file_mask))
            except OSError as exc:
                raise DeliveryError(f"Cannot chmod {int_path}: {exc}") from exc

        try:
            os.rename(int_path, final_path)
        except OSError as exc:
            raise DeliveryError(
                f"Cannot rename {int_path} → {final_path}: {exc}"
            ) from exc

        log.debug("Local delivery: %s → %s", sf.path, final_path)

    # ------------------------------------------------------------------
    # SFTP delivery
    # ------------------------------------------------------------------

    def _deliver_sftp(
        self, sf: StructuredFile, route: RouteEntry, content: str
    ) -> None:
        """Upload via SFTP: write to remote intermediate dir, then rename."""
        # Determine remote filename
        if route.transfer_method == "F":
            # Sequence-renamed: advance the counter once per file
            if not self._name_seq_used:
                if self._name_seq is None:
                    raise DeliveryError(
                        "F-mechanism route requires .NAME_SEQUENCE_FILE to be configured"
                    )
                self._name_seq.get_next()
                self._name_seq_used = True
            remote_name = self._name_seq.current  # type: ignore[union-attr]
        else:
            remote_name = sf.filename  # R-mechanism: keep original name

        remote_tmp   = str(PurePosixPath(route.intermediate_dir) / remote_name)
        remote_final = str(PurePosixPath(route.final_dest_dir)   / remote_name)

        conn = self._open_sftp(route.connect_data)
        with conn:
            conn.makedirs(route.intermediate_dir)
            conn.put_text(content, remote_tmp)
            conn.rename(remote_tmp, remote_final)

        log.debug("SFTP delivery: %s → %s:%s", sf.path, route.connect_data, remote_final)

    def _open_sftp(self, host: str) -> SFTPConnection:
        """Open an SFTP connection to *host* using the configured auth method."""
        cfg = self._cfg
        try:
            username, password = find_machine(host)
        except NetrcError as exc:
            if cfg.sftp_auth_method == "key":
                # For key auth the password is unused; username is still needed
                raise RoutingError(
                    f"Cannot find username for {host} in ~/.netrc: {exc}"
                ) from exc
            raise RoutingError(str(exc)) from exc

        if cfg.sftp_auth_method == "key":
            if not cfg.sftp_key_file:
                raise RoutingError(
                    "SFTP_AUTH_METHOD=key but .SFTP_KEY_FILE is not configured"
                )
            return open_sftp(
                host=host, username=username,
                key_file=cfg.sftp_key_file,
                key_passphrase=cfg.sftp_key_passphrase or None,
            )
        return open_sftp(host=host, username=username, password=password)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parse_octal_mode(s: str) -> int:
    """Parse 3-digit octal string (e.g. '644') to an int."""
    if len(s) == 3 and s.isdigit():
        return int(s[0]) * 64 + int(s[1]) * 8 + int(s[2])
    return 0o660

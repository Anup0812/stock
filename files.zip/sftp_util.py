"""
sftp_util.py - SFTP transport layer (replaces FTP).

Design improvements over v1
----------------------------
1.  Raises typed exceptions (SFTPConnectionError, SFTPAuthError,
    SFTPTransferError) instead of a single SFTPError for everything.
    Callers can catch only what they care about.

2.  Key loading uses a cleaner factory: try each key type in order and
    raise SFTPAuthError with a clear message on total failure.

3.  `SFTPConnection` is a context manager — the preferred usage is:

        with SFTPConnection.connect_password(host, user, pwd) as sftp:
            sftp.put(local, remote)

    Named constructors (`connect_password`, `connect_key`) make the
    intent explicit at the call site.

4.  `makedirs` properly handles race conditions with a targeted
    OSError.errno check rather than swallowing all exceptions.
"""

from __future__ import annotations

import errno as _errno
from pathlib import Path, PurePosixPath
from typing import Optional

from .exceptions import SFTPConnectionError, SFTPAuthError, SFTPTransferError

try:
    import paramiko
    _HAS_PARAMIKO = True
except ImportError:
    _HAS_PARAMIKO = False

_KEY_LOADERS = []
if _HAS_PARAMIKO:
    _KEY_LOADERS = [
        paramiko.Ed25519Key,
        paramiko.RSAKey,
        paramiko.ECDSAKey,
        paramiko.DSSKey,
    ]


def _require_paramiko() -> None:
    if not _HAS_PARAMIKO:
        raise ImportError(
            "The 'paramiko' package is required for SFTP support. "
            "Install it with:  pip install paramiko"
        )


def _load_private_key(
    key_file: str, passphrase: Optional[str]
) -> "paramiko.PKey":
    """
    Try each known key type in order and return the first that loads.
    Raises :class:`SFTPAuthError` if none succeed.
    """
    _require_paramiko()
    pw = passphrase or None
    last_exc: Optional[Exception] = None
    for klass in _KEY_LOADERS:
        try:
            return klass.from_private_key_file(key_file, password=pw)
        except (paramiko.ssh_exception.SSHException, ValueError) as exc:
            last_exc = exc
    raise SFTPAuthError(
        f"Could not load private key {key_file!r}: {last_exc}"
    )


class SFTPConnection:
    """
    A managed SFTP session.

    Prefer using as a context manager::

        with SFTPConnection.connect_password(host, user, pw) as sftp:
            sftp.put(local_path, remote_path)
    """

    def __init__(
        self,
        ssh: "paramiko.SSHClient",
        sftp: "paramiko.SFTPClient",
    ) -> None:
        self._ssh  = ssh
        self._sftp = sftp

    # ------------------------------------------------------------------
    # Named constructors
    # ------------------------------------------------------------------

    @classmethod
    def connect_password(
        cls,
        host: str,
        username: str,
        password: str,
        port: int = 22,
        timeout: float = 30.0,
    ) -> "SFTPConnection":
        """
        Open a password-authenticated SFTP connection.

        Raises :class:`SFTPConnectionError` or :class:`SFTPAuthError`.
        """
        _require_paramiko()
        ssh = _make_ssh_client()
        try:
            ssh.connect(
                hostname=host, port=port, username=username,
                password=password, timeout=timeout,
                allow_agent=False, look_for_keys=False,
            )
        except paramiko.AuthenticationException as exc:
            raise SFTPAuthError(f"Authentication failed for {username}@{host}: {exc}") from exc
        except Exception as exc:
            raise SFTPConnectionError(f"Cannot connect to {host}:{port}: {exc}") from exc
        return cls(ssh, ssh.open_sftp())

    @classmethod
    def connect_key(
        cls,
        host: str,
        username: str,
        key_file: str,
        key_passphrase: Optional[str] = None,
        port: int = 22,
        timeout: float = 30.0,
    ) -> "SFTPConnection":
        """
        Open a key-authenticated (passwordless) SFTP connection.

        Raises :class:`SFTPAuthError` if the key cannot be loaded or
        authentication fails; :class:`SFTPConnectionError` on network error.
        """
        _require_paramiko()
        key = _load_private_key(key_file, key_passphrase)
        ssh = _make_ssh_client()
        try:
            ssh.connect(
                hostname=host, port=port, username=username,
                pkey=key, timeout=timeout,
                allow_agent=False, look_for_keys=False,
            )
        except paramiko.AuthenticationException as exc:
            raise SFTPAuthError(f"Key auth failed for {username}@{host}: {exc}") from exc
        except Exception as exc:
            raise SFTPConnectionError(f"Cannot connect to {host}:{port}: {exc}") from exc
        return cls(ssh, ssh.open_sftp())

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "SFTPConnection":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    def close(self) -> None:
        """Close SFTP and SSH connections, ignoring errors."""
        for obj in (self._sftp, self._ssh):
            try:
                obj.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def put(self, local_path: str, remote_path: str) -> None:
        """Upload *local_path* to *remote_path*."""
        try:
            self._sftp.put(local_path, remote_path)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP put {local_path!r} → {remote_path!r}: {exc}"
            ) from exc

    def put_text(self, text: str, remote_path: str, encoding: str = "latin-1") -> None:
        """Write *text* directly to *remote_path* (no local temp file)."""
        import io
        data = text.encode(encoding)
        try:
            with self._sftp.open(remote_path, "wb") as fh:
                fh.write(data)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP write {remote_path!r}: {exc}"
            ) from exc

    def get(self, remote_path: str, local_path: str) -> None:
        """Download *remote_path* to *local_path*."""
        try:
            self._sftp.get(remote_path, local_path)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP get {remote_path!r} → {local_path!r}: {exc}"
            ) from exc

    def rename(self, old_path: str, new_path: str) -> None:
        """Rename a remote file."""
        try:
            self._sftp.rename(old_path, new_path)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP rename {old_path!r} → {new_path!r}: {exc}"
            ) from exc

    def delete(self, remote_path: str) -> None:
        """Delete a remote file."""
        try:
            self._sftp.remove(remote_path)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP delete {remote_path!r}: {exc}"
            ) from exc

    def list_dir(self, remote_path: str) -> list[str]:
        """Return a list of filenames in *remote_path*."""
        try:
            return self._sftp.listdir(remote_path)
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP listdir {remote_path!r}: {exc}"
            ) from exc

    def makedirs(self, remote_path: str) -> None:
        """Create *remote_path* and all parent directories."""
        sftp = self._sftp
        parts = PurePosixPath(remote_path).parts
        current = ""
        for part in parts:
            current = str(PurePosixPath(current) / part) if current else part
            try:
                sftp.stat(current)
            except FileNotFoundError:
                try:
                    sftp.mkdir(current)
                except OSError as exc:
                    if exc.errno != _errno.EEXIST:
                        raise SFTPTransferError(
                            f"SFTP mkdir {current!r}: {exc}"
                        ) from exc

    def file_exists(self, remote_path: str) -> bool:
        """Return True if *remote_path* exists on the server."""
        try:
            self._sftp.stat(remote_path)
            return True
        except FileNotFoundError:
            return False
        except Exception as exc:
            raise SFTPTransferError(
                f"SFTP stat {remote_path!r}: {exc}"
            ) from exc


def _make_ssh_client() -> "paramiko.SSHClient":
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    return client


# ---------------------------------------------------------------------------
# Factory helper (used by main.py)
# ---------------------------------------------------------------------------

def open_sftp(
    host: str,
    username: str,
    password: Optional[str] = None,
    key_file: Optional[str] = None,
    key_passphrase: Optional[str] = None,
    port: int = 22,
) -> SFTPConnection:
    """
    Open an SFTP connection, choosing auth method automatically.

    * *key_file* supplied  → key-based auth
    * otherwise            → password auth (*password* required)
    """
    if key_file:
        return SFTPConnection.connect_key(
            host=host, username=username,
            key_file=key_file, key_passphrase=key_passphrase,
            port=port,
        )
    if not password:
        raise SFTPAuthError(
            f"No password or key_file given for {username}@{host}"
        )
    return SFTPConnection.connect_password(
        host=host, username=username, password=password, port=port
    )

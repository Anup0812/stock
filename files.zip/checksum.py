"""
checksum.py - XOR-based 32-bit checksum (replicates pf_checksum.c).

Design improvement over v1
---------------------------
- `checksum_of()` is a pure function with no side effects.
  Give it data, get back a number.  Trivially testable.
- `ChecksumAccumulator` is a small stateful helper for the
  incremental case (building a checksum line-by-line over a file).
  State is fully encapsulated in the instance — no module globals.
"""

from __future__ import annotations


# ---------------------------------------------------------------------------
# Pure function (preferred for single-shot use)
# ---------------------------------------------------------------------------

def checksum_of(data: str | bytes) -> int:
    """
    Return the XOR checksum of *data* as a 32-bit unsigned integer.

    Data is split into 4-byte groups. Each group is packed into a
    big-endian 32-bit integer (short final groups are zero-padded),
    then XOR-ed into the running total.

    >>> checksum_of(b"")
    0
    >>> checksum_of("ABCD") == checksum_of(b"ABCD")
    True
    """
    raw = data.encode("latin-1") if isinstance(data, str) else bytes(data)
    total = 0
    for i in range(0, len(raw), 4):
        chunk = 0
        for j in range(4):
            chunk <<= 8
            if i + j < len(raw):
                chunk += raw[i + j]
        total ^= chunk
    return total & 0xFFFF_FFFF


# ---------------------------------------------------------------------------
# Stateful accumulator (for incremental line-by-line use)
# ---------------------------------------------------------------------------

class ChecksumAccumulator:
    """
    Accumulates an XOR checksum incrementally.

    All state is in the instance; safe to create one per file.

    Example::

        acc = ChecksumAccumulator()
        for line in file_lines:
            acc.add(line)
        print(acc.value)          # integer
        print(acc.value_str)      # decimal string
    """

    __slots__ = ("_total",)

    def __init__(self) -> None:
        self._total: int = 0

    def add(self, data: str | bytes) -> None:
        """Add *data* to the running checksum."""
        self._total ^= checksum_of(data)
        self._total &= 0xFFFF_FFFF

    def reset(self) -> None:
        """Reset the accumulator to zero."""
        self._total = 0

    @property
    def value(self) -> int:
        """Current 32-bit checksum as an integer."""
        return self._total

    @property
    def value_str(self) -> str:
        """Current checksum as an unsigned decimal string."""
        return str(self._total)

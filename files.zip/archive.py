"""
archive.py - Archive directory management.

Design fix over v1
------------------
In v1, Archive was constructed with a `header_fn` callback that was
wired to a placeholder returning "" — a functional bug that would have
produced archive sub-directories named "___" for every file.

Fix: `archive_file()` receives the `FileHeader` directly as an argument.
No callback needed; no risk of stale state.
"""

from __future__ import annotations

import errno
import logging
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

from .structured_file import FileHeader

log = logging.getLogger(__name__)


class Archive:
    """
    Manages the archive tree for one router run.

    Call :meth:`create_run_dir` once at startup, then call
    :meth:`archive_file` for every processed file.

    Archive layout::

        <root>/YYYYMMDD/<run_no>/<PART>_<FLAG>_<TYPE>_<VER>/<filename>
    """

    def __init__(self, root: str) -> None:
        self._root = root
        self._run_number: int = 0
        self._date_dir: str = ""

    # ------------------------------------------------------------------
    # Startup
    # ------------------------------------------------------------------

    def create_run_dir(self) -> None:
        """
        Determine the next run number and create the run directory.
        Must be called once before any :meth:`archive_file` calls.
        """
        stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d")
        self._date_dir = str(Path(self._root) / stamp)
        Path(self._date_dir).mkdir(parents=True, exist_ok=True)

        max_run = 0
        for entry in Path(self._date_dir).iterdir():
            if entry.is_dir() and entry.name.isdigit():
                max_run = max(max_run, int(entry.name))

        self._run_number = max_run + 1
        Path(self._run_dir).mkdir(parents=True, exist_ok=True)
        log.info("Archive run directory: %s", self._run_dir)

    @property
    def _run_dir(self) -> str:
        return str(Path(self._date_dir) / str(self._run_number))

    @property
    def run_number(self) -> int:
        return self._run_number

    # ------------------------------------------------------------------
    # Per-file archiving
    # ------------------------------------------------------------------

    def archive_file(self, source_path: str, header: FileHeader) -> str:
        """
        Move *source_path* into the archive.

        Parameters
        ----------
        source_path : full path of the file to archive
        header      : the file's parsed header (provides sub-dir name)

        Returns the final archive path.
        """
        test_flag = header.test_flag or "null"
        subdir = (
            f"{header.dst_part}_{test_flag}_"
            f"{header.file_type}_{header.file_version}"
        )
        subdir_path = Path(self._run_dir) / subdir
        subdir_path.mkdir(parents=True, exist_ok=True)

        dest = subdir_path / Path(source_path).name
        # Avoid collisions
        while dest.exists():
            dest = Path(str(dest) + ".x")

        _atomic_move(str(source_path), str(dest))
        return str(dest)


def _atomic_move(src: str, dst: str) -> None:
    """
    Move *src* to *dst*, falling back to copy+delete on cross-device moves.
    Raises OSError on failure.
    """
    try:
        os.rename(src, dst)
    except OSError as exc:
        if exc.errno == errno.EXDEV:
            shutil.copy2(src, dst)
            os.unlink(src)
        else:
            raise

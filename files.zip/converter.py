"""
converter.py - Per-file format conversion (ZHV / ZHD / ZPT records).

Design improvement over v1
---------------------------
The original C code (and the v1 Python rewrite) stored `saved_file_id`
as a static/module-level variable.  That means:

  * Two files processed in the same process share the variable.
  * A crash mid-file leaves stale state for the next file.
  * Unit tests that call conv_line() multiple times interfere with each
    other unless run in separate processes.

Fix: `FormatConverter` is a class.  One instance is created per file
(owned by `StructuredFile`).  `saved_file_id` lives on the instance.
No module-level mutable state exists anywhere in this module.

File format codes
-----------------
  U   User File Format         ZHV header
  P   Pool File Format         ZHD header (6 delimiters)
  T   Pool Transfer Format     ZHD header (11 delimiters)
"""

from __future__ import annotations

from . import record as R


class FormatConverter:
    """
    Converts individual record lines between file formats U, P, and T.

    Create one instance per input file and use :meth:`convert_line`
    to transform each line as it is read.  The instance tracks the
    file-ID seen in the header so the footer can reference it.

    Parameters
    ----------
    src_fmt : source file format code ('U', 'P', or 'T')
    dst_fmt : target file format code ('U', 'P', or 'T')
    """

    def __init__(self, src_fmt: str, dst_fmt: str) -> None:
        self.src = src_fmt
        self.dst = dst_fmt
        self._file_id: str = ""      # captured from header, used in footer

    @property
    def saved_file_id(self) -> str:
        """The file-ID parsed from the most recent header record."""
        return self._file_id

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def convert_line(
        self,
        line: str,
        req_file_id: str = "",
        req_csum: str = "",
        force_csum: bool = False,
        req_tflag: str = "",
    ) -> str:
        """
        Convert a single *line* from :attr:`src` format to :attr:`dst`.

        Parameters
        ----------
        line         : the raw record line
        req_file_id  : file-ID to embed when promoting from Pool format
        req_csum     : checksum string for footer rewrite
        force_csum   : True → always write checksum even if original was null
        req_tflag    : test flag to embed in header when converting from P
        """
        # Determine which file_id to embed in footer records.
        # When source is Pool (P), the caller supplies req_file_id.
        # Otherwise we use the ID we captured from the header.
        embed_id = req_file_id if self.src == "P" else self._file_id

        if line.startswith("ZHV"):
            return self._conv_zhv(line, req_tflag)
        elif line.startswith("ZHD"):
            return self._conv_zhd(line, req_file_id, req_tflag)
        elif line.startswith("ZPT"):
            return self._conv_zpt(line, embed_id, req_csum, force_csum)
        else:
            return self._conv_data(line)

    # ------------------------------------------------------------------
    # Header conversions
    # ------------------------------------------------------------------

    def _conv_zhv(self, line: str, req_tflag: str) -> str:
        """ZHV is the User-format header."""
        s = R.parse(line)
        self._file_id = R.seg(s, 1)

        if self.dst == "P":
            return (f"ZHD|{R.seg(s,2)}|{R.seg(s,3)}"
                    f"|{R.seg(s,4)}|{R.seg(s,5)}"
                    f"|{R.seg(s,6)}|{R.seg(s,7)}")
        elif self.dst == "T":
            return (f"ZHD|{R.seg(s,1)}|{R.seg(s,2)}"
                    f"|{R.seg(s,3)}|{R.seg(s,4)}"
                    f"|{R.seg(s,5)}|{R.seg(s,6)}"
                    f"|{R.seg(s,7)}||||{R.seg(s,11)}")
        else:
            return line  # U → U: pass through

    def _conv_zhd(self, line: str, req_file_id: str, req_tflag: str) -> str:
        """ZHD is the Pool / Transfer header."""
        s = R.parse(line)

        if self.src == "P" and self.dst == "T":
            self._file_id = req_file_id
            return (f"ZHD|{req_file_id}|{R.seg(s,1)}"
                    f"|{R.seg(s,2)}|{R.seg(s,3)}"
                    f"|{R.seg(s,4)}|{R.seg(s,5)}"
                    f"|{R.seg(s,6)}||||{req_tflag}")

        elif self.src == "P" and self.dst == "U":
            self._file_id = req_file_id
            return (f"ZHV|{req_file_id}|{R.seg(s,1)}"
                    f"|{R.seg(s,2)}|{R.seg(s,3)}"
                    f"|{R.seg(s,4)}|{R.seg(s,5)}"
                    f"|{R.seg(s,6)}||||{req_tflag}|")

        elif self.src == "T" and self.dst == "U":
            self._file_id = R.seg(s, 1)
            return (f"ZHV|{R.seg(s,1)}|{R.seg(s,2)}"
                    f"|{R.seg(s,3)}|{R.seg(s,4)}"
                    f"|{R.seg(s,5)}|{R.seg(s,6)}"
                    f"|{R.seg(s,7)}||||{R.seg(s,11)}|")

        elif self.src == "T" and self.dst == "P":
            self._file_id = R.seg(s, 1)
            return (f"ZHD|{R.seg(s,2)}|{R.seg(s,3)}"
                    f"|{R.seg(s,4)}|{R.seg(s,5)}"
                    f"|{R.seg(s,6)}|{R.seg(s,7)}")

        elif self.src == "T" and self.dst == "T":
            self._file_id = R.seg(s, 1)
            return line  # T → T: pass through

        else:
            # P → P: pass through
            self._file_id = req_file_id
            return line

    # ------------------------------------------------------------------
    # Footer conversion
    # ------------------------------------------------------------------

    def _conv_zpt(
        self,
        line: str,
        embed_id: str,
        req_csum: str,
        force_csum: bool,
    ) -> str:
        """ZPT is the footer/trailer record."""
        s = R.parse(line)

        if self.src == "U" and self.dst in ("P", "T"):
            count = int(R.seg(s, 2) or "0") + 2
            return f"ZPT|{count}|{req_csum}"

        elif self.src == "U" and self.dst == "U":
            count = int(R.seg(s, 2) or "0")
            existing_csum = R.seg(s, 3)
            use_csum = req_csum if (existing_csum or force_csum) else ""
            return (f"ZPT|{embed_id}|{count}|{use_csum}|"
                    f"{R.seg(s,4)}|{R.seg(s,5)}|")

        elif self.src in ("P", "T") and self.dst == "U":
            count = int(R.seg(s, 1) or "0") - 2
            return f"ZPT|{embed_id}|{count}|{req_csum}|||"

        elif self.src in ("P", "T") and self.dst in ("P", "T"):
            count = int(R.seg(s, 1) or "0")
            return f"ZPT|{count}|{req_csum}"

        return line

    # ------------------------------------------------------------------
    # Data record conversion
    # ------------------------------------------------------------------

    def _conv_data(self, line: str) -> str:
        """Apply trailing-pipe add/remove for data records."""
        if self.src == "U" and self.dst in ("P", "T"):
            return R.drop_trailing_pipe_segment(line)
        elif self.dst == "U" and self.src in ("P", "T"):
            return line + "|"
        return line

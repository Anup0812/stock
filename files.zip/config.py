"""
config.py - Configuration file parser.

Design improvements over v1
----------------------------
1.  Config is a proper frozen dataclass — not a mutable object where
    fields can be silently changed after loading.

2.  All validation errors are collected and reported together, not one
    at a time.  If your config has 5 errors you see all 5 at once.

3.  Route entries are parsed into a `RouteEntry` dataclass with named
    fields (not accessed via single-char switches like pr_get_route_dets('X')).

4.  The new SFTP directives (.SFTP_AUTH_METHOD, .SFTP_KEY_FILE,
    .SFTP_KEY_PASSPHRASE) are supported alongside the original format.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .exceptions import ConfigError


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class InputDir:
    """A single .INPUT_DIR entry."""
    dir_type: str   # 'L', 'I', or 'F'
    path:     str
    machine:  str


@dataclass(frozen=True)
class RouteEntry:
    """A single routing table row (11 fields)."""
    inhibit:          str   # Y N F I D
    distributor:      str   # 4-char or *
    file_type:        str   # 5 chars
    file_version:     str   # 3 chars
    role_code:        str   # 1 char or *
    test_flag:        str   # e.g. OPER
    output_format:    str   # U P T
    transfer_method:  str   # L F R
    intermediate_dir: str
    final_dest_dir:   str
    connect_data:     str   # hostname or 'null'

    @property
    def is_sftp(self) -> bool:
        return self.transfer_method in ("F", "R")

    @property
    def is_local(self) -> bool:
        return self.transfer_method == "L"

    @property
    def is_inhibited(self) -> bool:
        return self.inhibit not in ("Y", "F")

    @property
    def force_checksum(self) -> bool:
        return self.inhibit == "F"


@dataclass(frozen=True)
class RouterConfig:
    """Complete parsed and validated configuration."""
    machine_name:        str
    archive_root:        str
    temp_dir:            str
    log_dir:             str
    sequence_file:       str
    name_sequence_file:  str
    file_mask:           str

    sftp_auth_method:    str   # 'password' or 'key'
    sftp_key_file:       str
    sftp_key_passphrase: str

    input_dirs:          tuple[InputDir, ...]
    routes:              tuple[RouteEntry, ...]


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def load_config(config_path: str) -> RouterConfig:
    """
    Parse and validate *config_path*.

    Raises :class:`ConfigError` with all errors listed if validation fails.
    """
    path = Path(config_path)
    if not path.exists():
        raise ConfigError(f"Configuration file not found: {config_path}")

    raw_lines = path.read_text(encoding="utf-8", errors="replace").splitlines()

    # Mutable working state
    params: dict[str, str] = {
        "machine_name":        "",
        "archive_root":        "",
        "temp_dir":            "",
        "log_dir":             "",
        "sequence_file":       "",
        "name_sequence_file":  "",
        "file_mask":           "",
        "sftp_auth_method":    "password",
        "sftp_key_file":       "",
        "sftp_key_passphrase": "",
    }
    input_dirs: list[InputDir] = []
    routes:     list[RouteEntry] = []
    errors:     list[str] = []

    _DIRECTIVE_MAP = {
        ".MACHINE_NAME":        "machine_name",
        ".ARCHIVE_ROOT":        "archive_root",
        ".TEMP_DIR":            "temp_dir",
        ".LOG_DIR":             "log_dir",
        ".SEQUENCE_FILE":       "sequence_file",
        ".NAME_SEQUENCE_FILE":  "name_sequence_file",
        ".FILE_MASK":           "file_mask",
        ".SFTP_AUTH_METHOD":    "sftp_auth_method",
        ".SFTP_KEY_FILE":       "sftp_key_file",
        ".SFTP_KEY_PASSPHRASE": "sftp_key_passphrase",
    }

    for line_no, raw in enumerate(raw_lines, start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue

        if line.startswith("."):
            parts = line.split(None, 3)
            key = parts[0].upper()
            value = parts[1] if len(parts) > 1 else ""

            if key in _DIRECTIVE_MAP:
                params[_DIRECTIVE_MAP[key]] = value
            elif key == ".INPUT_DIR":
                _parse_input_dir(parts, line_no, input_dirs, errors)
            # unknown directives silently ignored for forward compatibility
            continue

        # Route table entry
        fields = line.split()
        if len(fields) == 11:
            entry = RouteEntry(*fields)
            _validate_route(entry, line_no, errors)
            routes.append(entry)
        elif fields:
            errors.append(
                f"Line {line_no}: expected 11 fields, got {len(fields)}: {line!r}"
            )

    # Validate SFTP auth method value
    if params["sftp_auth_method"] not in ("password", "key"):
        errors.append(
            f".SFTP_AUTH_METHOD must be 'password' or 'key', "
            f"got {params['sftp_auth_method']!r}"
        )

    if errors:
        raise ConfigError(
            f"Configuration file {config_path!r} has {len(errors)} error(s):\n"
            + "\n".join(f"  • {e}" for e in errors)
        )

    return RouterConfig(
        **params,
        input_dirs = tuple(input_dirs),
        routes     = tuple(routes),
    )


def _parse_input_dir(
    parts: list[str],
    line_no: int,
    out: list[InputDir],
    errors: list[str],
) -> None:
    if len(parts) < 4:
        errors.append(
            f"Line {line_no}: .INPUT_DIR needs <type> <path> <machine>"
        )
        return
    dir_type = parts[1].upper()
    if dir_type not in ("L", "I", "F"):
        errors.append(
            f"Line {line_no}: .INPUT_DIR type must be L, I, or F – got {dir_type!r}"
        )
        return
    out.append(InputDir(dir_type=dir_type, path=parts[2], machine=parts[3]))


def _validate_route(r: RouteEntry, line_no: int, errors: list[str]) -> None:
    if r.inhibit not in ("Y", "N", "F", "I", "D"):
        errors.append(f"Line {line_no}: inhibit must be Y/N/F/I/D, got {r.inhibit!r}")
    if len(r.distributor) == 1 and r.distributor != "*":
        errors.append(f"Line {line_no}: 1-char distributor must be '*'")
    elif len(r.distributor) not in (1, 4):
        errors.append(f"Line {line_no}: distributor must be 1 or 4 chars")
    if len(r.file_type) != 5:
        errors.append(f"Line {line_no}: file_type must be 5 chars")
    if len(r.file_version) != 3:
        errors.append(f"Line {line_no}: file_version must be 3 chars")
    if r.output_format not in ("U", "P", "T"):
        errors.append(f"Line {line_no}: output_format must be U/P/T")
    if r.transfer_method not in ("L", "F", "R"):
        errors.append(f"Line {line_no}: transfer_method must be L/F/R")
    if r.is_sftp and r.connect_data in ("", "null"):
        errors.append(f"Line {line_no}: SFTP route needs a connect_data hostname")


# ---------------------------------------------------------------------------
# Route matching — a generator (no manual reset() needed)
# ---------------------------------------------------------------------------

def matching_routes(
    cfg: RouterConfig,
    file_type: str,
    file_version: str,
    dst_role: str,
    dst_part: str,
    test_flag: str,
    allow_wildcard: bool,
) -> list[RouteEntry]:
    """
    Return all route entries that match the given file parameters.

    Using a plain function that returns a list is simpler and more
    testable than a stateful RouteMatcher class with a reset() method.
    The cost is a single O(N) scan of the routes list — fine for
    the typical config size of a few dozen entries.
    """
    wildcard = "*" if allow_wildcard else "\x00"
    results = []
    for r in cfg.routes:
        if (
            r.file_type    == file_type
            and r.file_version == file_version
            and (r.distributor == dst_part or r.distributor == wildcard)
            and (r.role_code   == dst_role  or r.role_code   == wildcard)
            and (r.test_flag   == test_flag  or not test_flag)
        ):
            results.append(r)
    return results

"""
record.py - Pipe-delimited record parsing utilities (pure / stateless).

Design improvement over v1
---------------------------
In v1 (pf_string.py) the parse state lived in module-level arrays
(parsed[], parsed_segments).  That meant calling pf_str_parse() twice
on different data from different call sites would silently clobber the
first result.

Here every function is pure: give it input, get back output.  No module
state whatsoever.  Trivially testable and thread-safe.

The stateful format-conversion logic (which needs to remember the
file-ID from the header to use in the footer) lives in
`FormatConverter` in converter.py — one instance per file, owned by the
`StructuredFile` object.
"""

from __future__ import annotations


def parse(line: str) -> list[str]:
    """
    Split a pipe-delimited *line* into a list of segment strings.

    A trailing pipe produces a final empty-string segment, matching
    the original C behaviour.

    >>> parse("ZHV|id|type|role")
    ['ZHV', 'id', 'type', 'role']
    >>> parse("ZHV|id|")
    ['ZHV', 'id', '']
    """
    return line.split("|")


def seg(segments: list[str], index: int) -> str:
    """
    Return segment *index* from *segments*.
    Returns an empty string when *index* is out of range.

    >>> seg(['a', 'b', 'c'], 1)
    'b'
    >>> seg(['a'], 5)
    ''
    """
    return segments[index] if index < len(segments) else ""


def count_pipes(line: str) -> int:
    """Return the number of pipe characters in *line*.

    >>> count_pipes("A|B|C")
    2
    """
    return line.count("|")


def is_numeric(s: str) -> bool:
    """Return True if *s* is a non-empty string of digits only.

    >>> is_numeric("123")
    True
    >>> is_numeric("")
    False
    """
    return bool(s) and s.isdigit()


def get_field(line: str, field_index: int) -> str:
    """
    Extract field *field_index* (0-based) from a pipe-delimited *line*.
    Returns an empty string if the field does not exist.

    >>> get_field("A|B|C", 1)
    'B'
    """
    parts = line.split("|")
    return parts[field_index] if field_index < len(parts) else ""


def trim_path(s: str) -> str:
    """
    Return the filename portion of *s* (everything after the last '/').

    >>> trim_path("/a/b/c.txt")
    'c.txt'
    >>> trim_path("nopath.txt")
    'nopath.txt'
    """
    idx = s.rfind("/")
    return s[idx + 1:] if idx >= 0 else s


def drop_trailing_pipe_segment(s: str) -> str:
    """
    Remove the last pipe character and everything after it.

    Used when converting U-format data records to P/T (which have no
    trailing pipe on each data line).

    >>> drop_trailing_pipe_segment("DATA|FIELDS|")
    'DATA|FIELDS'
    """
    idx = s.rfind("|")
    return s[:idx] if idx >= 0 else s

"""
tests/test_core.py - Unit tests (stdlib unittest only, no pytest required).
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import unittest
import tempfile
from pathlib import Path

from mdns_router.checksum import checksum_of, ChecksumAccumulator
from mdns_router.converter import FormatConverter
from mdns_router.record import parse, seg, count_pipes, is_numeric, trim_path
from mdns_router.structured_file import StructuredFile, FooterResult
from mdns_router.config import RouterConfig, RouteEntry, InputDir, matching_routes
from mdns_router.exceptions import ConfigError, UnrecognisedFormatError

def _make_cfg(routes):
    return RouterConfig(
        machine_name="", archive_root="", temp_dir="", log_dir="",
        sequence_file="", name_sequence_file="", file_mask="",
        sftp_auth_method="password", sftp_key_file="", sftp_key_passphrase="",
        input_dirs=(), routes=tuple(routes),
    )

def _make_sf(lines):
    return StructuredFile(path="<memory>", lines=lines)


class TestChecksum(unittest.TestCase):
    def test_empty(self): self.assertEqual(checksum_of(b""), 0)
    def test_str_bytes_eq(self): self.assertEqual(checksum_of("ABCD"), checksum_of(b"ABCD"))
    def test_accumulator_reset(self):
        a = ChecksumAccumulator(); a.add("hello"); a.reset()
        self.assertEqual(a.value, 0)
    def test_accumulator_per_instance(self):
        a, b = ChecksumAccumulator(), ChecksumAccumulator()
        a.add("hello")
        self.assertEqual(b.value, 0)


class TestRecord(unittest.TestCase):
    def test_parse(self): self.assertEqual(parse("A|B|C"), ["A","B","C"])
    def test_trailing_pipe(self): self.assertEqual(parse("A|B|"), ["A","B",""])
    def test_seg_oob(self): self.assertEqual(seg(["A"],10), "")
    def test_count_pipes(self): self.assertEqual(count_pipes("A|B|C"), 2)
    def test_is_numeric(self):
        self.assertTrue(is_numeric("123")); self.assertFalse(is_numeric(""))
    def test_trim_path(self): self.assertEqual(trim_path("/a/b/c.txt"), "c.txt")


class TestConverter(unittest.TestCase):
    def test_no_global_state_leak(self):
        """THE KEY TEST: two converter instances must be independent."""
        a = FormatConverter("U", "P")
        b = FormatConverter("U", "P")
        a.convert_line("ZHV|FILE_A|D0030001|R|NEEB|X|OPER|||||||")
        b.convert_line("ZHV|FILE_B|D0242001|P|YELG|R|TR01|||||||")
        self.assertEqual(a.saved_file_id, "FILE_A")
        self.assertEqual(b.saved_file_id, "FILE_B")
        self.assertNotEqual(a.saved_file_id, b.saved_file_id)

    def test_u_to_p_header(self):
        c = FormatConverter("U","P")
        r = c.convert_line("ZHV|MYID|D0030001|R|NEEB|X|OPER|||||||")
        self.assertTrue(r.startswith("ZHD|"))
        self.assertEqual(c.saved_file_id, "MYID")

    def test_data_u_to_p_drops_pipe(self):
        c = FormatConverter("U","P")
        self.assertEqual(c.convert_line("DATA|F1|F2|"), "DATA|F1|F2")

    def test_data_p_to_u_adds_pipe(self):
        c = FormatConverter("P","U")
        self.assertEqual(c.convert_line("DATA|F1|F2"), "DATA|F1|F2|")

    def test_passthrough_u_to_u(self):
        c = FormatConverter("U","U")
        self.assertEqual(c.convert_line("DATA|F1|"), "DATA|F1|")


class TestStructuredFile(unittest.TestCase):
    def test_identify_u(self):
        sf = _make_sf(["ZHV|id|D0030001|R|NEEB|X|OPER|||||||"])
        self.assertEqual(sf.identify(), "U")

    def test_identify_p(self):
        sf = _make_sf(["ZHD|D0030001|R|NEEB|X|OPER|flag"])
        self.assertEqual(sf.identify(), "P")

    def test_identify_t(self):
        sf = _make_sf(["ZHD|fileid|D0030001|R|NEEB|X|OPER|serial||||OPER"])
        self.assertEqual(sf.identify(), "T")

    def test_identify_empty_raises(self):
        with self.assertRaises(UnrecognisedFormatError):
            _make_sf([]).identify()

    def test_identify_zhf_raises(self):
        with self.assertRaises(UnrecognisedFormatError):
            _make_sf(["ZHF|fixed"]).identify()


class TestConfig(unittest.TestCase):
    def test_collects_multiple_errors(self):
        with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False) as f:
            f.write(".ARCHIVE_ROOT /a\n.LOG_DIR /l\n.TEMP_DIR /t\n")
            f.write("N *X D003 01 RR OPER UU ZZ /i /f bad\n")
            name = f.name
        try:
            from mdns_router.config import load_config
            with self.assertRaises(ConfigError) as ctx:
                load_config(name)
            msg = str(ctx.exception)
            self.assertIn("file_type", msg)
            self.assertIn("file_version", msg)
        finally:
            os.unlink(name)

    def test_valid_minimal(self):
        with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False) as f:
            f.write(".ARCHIVE_ROOT /a\n.LOG_DIR /l\n.TEMP_DIR /t\n.MACHINE_NAME test\n")
            f.write(".INPUT_DIR L /input null\n")
            f.write("Y NEEB D0030 001 R OPER U L /int /fin null\n")
            name = f.name
        try:
            from mdns_router.config import load_config
            cfg = load_config(name)
            self.assertEqual(cfg.machine_name, "test")
            self.assertEqual(len(cfg.routes), 1)
        finally:
            os.unlink(name)


class TestRouteMatching(unittest.TestCase):
    def _cfg(self):
        return _make_cfg([
            RouteEntry("Y","NEEB","D0030","001","R","OPER","U","L","/i","/f","null"),
            RouteEntry("Y","YELG","D0030","001","R","OPER","U","L","/i2","/f2","null"),
            RouteEntry("Y","*",   "D0242","001","R","OPER","P","L","/i3","/f3","null"),
        ])

    def test_exact_match(self):
        r = matching_routes(self._cfg(),"D0030","001","R","NEEB","OPER",True)
        self.assertEqual(len(r), 1); self.assertEqual(r[0].distributor,"NEEB")

    def test_wildcard(self):
        r = matching_routes(self._cfg(),"D0242","001","R","ANYD","OPER",True)
        self.assertEqual(len(r), 1); self.assertEqual(r[0].distributor,"*")

    def test_wildcard_blocked(self):
        r = matching_routes(self._cfg(),"D0242","001","R","ANYD","OPER",False)
        self.assertEqual(r, [])

    def test_no_match(self):
        r = matching_routes(self._cfg(),"D9999","001","R","NEEB","OPER",True)
        self.assertEqual(r, [])

    def test_multiple_routes(self):
        cfg = _make_cfg([
            RouteEntry("Y","NEEB","D0030","001","R","OPER","U","L","/a","/b","null"),
            RouteEntry("Y","*",   "D0030","001","R","OPER","P","L","/c","/d","null"),
        ])
        r = matching_routes(cfg,"D0030","001","R","NEEB","OPER",True)
        self.assertEqual(len(r), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""
main.py - MDNS File Router entry point.

Design improvements over v1
----------------------------
1.  Uses Python's standard `logging` module throughout — no custom
    logger channels 0-4 with manual file handles.  Log levels and
    destinations are configured via standard logging config.

2.  No sys.exit() in library code — only here at the outermost level.

3.  The Router class is constructed once and reused across all input
    directories.

4.  SFTP input loop is a clean generator-style loop; errors are
    logged per-file and the loop continues.

Usage::

    python -m mdns_router [--config PATH]

    Environment variable MDNS_CONFIG also accepted.
"""

from __future__ import annotations

import argparse
import logging
import logging.handlers
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from .config import load_config, RouterConfig
from .archive import Archive
from .sequence import SequenceFile
from .router import Router
from .sftp_util import open_sftp, SFTPError
from .netrc_util import find_machine, NetrcError
from .dir_scan import list_files_with_paths
from .exceptions import ConfigError, SFTPConnectionError


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def _setup_logging(log_dir: str, machine_name: str) -> None:
    """
    Configure standard Python logging to write to dated log files.

    Channel mapping (preserves the original 5-channel layout):
      INFO   → trace.log        (was channel 0)
      WARNING  named 'unmatched' → unmatched.log (channel 1)
    Since Python logging has levels not separate streams, we achieve the
    original 5-channel behaviour by using named loggers and separate file
    handlers.
    """
    stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d")
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    fmt = logging.Formatter(
        "%(asctime)s [%(name)s] %(levelname)s: %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
    )

    def _fh(name: str) -> logging.FileHandler:
        h = logging.FileHandler(str(log_path / f"{stamp}_{name}"), mode="a", encoding="utf-8")
        h.setFormatter(fmt)
        return h

    # Root logger → trace.log (all INFO+ messages)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(_fh("trace.log"))

    # Named loggers for specific channels
    for name, filename in [
        ("mdns.unmatched", "unmatched.log"),
        ("mdns.nack",      "nack_files.log"),
        ("mdns.bad",       "bad_files.log"),
        ("mdns.processed", "proc_files.log"),
    ]:
        lg = logging.getLogger(name)
        lg.addHandler(_fh(filename))
        lg.propagate = True  # also goes to trace.log

    # Console handler (INFO+)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(fmt)
    root.addHandler(console)

    logging.getLogger("mdns").info("Router starting on %s", machine_name)


log = logging.getLogger("mdns.main")


# ---------------------------------------------------------------------------
# SFTP input source
# ---------------------------------------------------------------------------

def _process_sftp_input(inp, cfg: RouterConfig, router: Router) -> None:
    log.info("Opening remote %s:%s", inp.machine, inp.path)

    try:
        username, password = find_machine(inp.machine)
    except NetrcError as exc:
        log.error("Cannot get credentials for %s: %s", inp.machine, exc)
        return

    key_file = cfg.sftp_key_file if cfg.sftp_auth_method == "key" else None

    try:
        sftp = open_sftp(
            host=inp.machine, username=username, password=password,
            key_file=key_file, key_passphrase=cfg.sftp_key_passphrase or None,
        )
    except (SFTPConnectionError, SFTPError) as exc:
        log.error("Cannot connect to %s: %s", inp.machine, exc)
        return

    with sftp:
        try:
            remote_files = sftp.list_dir(inp.path)
        except SFTPError as exc:
            log.error("Cannot list %s on %s: %s", inp.path, inp.machine, exc)
            return

        for remote_name in remote_files:
            if len(remote_name) < 4:
                continue

            local_path  = str(Path(cfg.temp_dir) / remote_name)
            remote_path = f"{inp.path}/{remote_name}"

            try:
                sftp.get(remote_path, local_path)
            except SFTPError as exc:
                log.error("Cannot fetch %s: %s", remote_path, exc)
                continue

            success = router.process_file(local_path, allow_wildcard=True)

            if success:
                try:
                    sftp.delete(remote_path)
                except SFTPError as exc:
                    log.error("Cannot delete remote %s: %s", remote_path, exc)
            else:
                try:
                    os.remove(local_path)
                except OSError:
                    pass


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        description="MDNS File Router — routes structured EDI-style files."
    )
    parser.add_argument(
        "--config", "-c",
        default=os.environ.get("MDNS_CONFIG", str(Path.home() / "mdns_router.ini")),
        help="Path to the router configuration file (default: ~/mdns_router.ini)",
    )
    args = parser.parse_args(argv)

    # Load config (may raise ConfigError)
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        sys.stderr.write(f"Configuration error:\n{exc}\n")
        sys.exit(1)

    # Set up logging now that we know the log directory
    _setup_logging(cfg.log_dir, cfg.machine_name)
    log.info("Configuration loaded from %s", args.config)

    # Create temp dir
    Path(cfg.temp_dir).mkdir(parents=True, exist_ok=True)

    # Archive — create the run directory once
    archive = Archive(cfg.archive_root)
    archive.create_run_dir()

    # Sequence files (None if not configured)
    seq      = SequenceFile(cfg.sequence_file)      if cfg.sequence_file      else None
    name_seq = SequenceFile(cfg.name_sequence_file) if cfg.name_sequence_file else None

    # Router (single instance across all input dirs)
    router = Router(cfg=cfg, archive=archive, seq=seq, name_seq=name_seq)

    # Process each input directory
    for inp in cfg.input_dirs:
        if inp.dir_type in ("L", "I"):
            allow_wildcard = (inp.dir_type == "L")
            files = list_files_with_paths(inp.path, sort_by_date=True)
            log.info("Source dir %s: %d file(s)", inp.path, len(files))
            for fp in files:
                router.process_file(fp, allow_wildcard=allow_wildcard)

        elif inp.dir_type == "F":
            _process_sftp_input(inp, cfg, router)

    # Close sequences
    if seq:
        seq.close()
    if name_seq:
        name_seq.close()

    log.info("Run complete. Archive run %d.", archive.run_number)


if __name__ == "__main__":
    main()

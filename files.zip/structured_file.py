"""
structured_file.py - A single structured input file, fully encapsulated.

Design improvements over v1
----------------------------
1.  No error callbacks — failures raise typed exceptions from exceptions.py.
    The caller decides whether to skip the file, abort, or log and continue.

2.  No module-level state — the FormatConverter instance lives here, and
    `saved_file_id` lives on that converter instance.

3.  Header parameters are parsed once into a `FileHeader` dataclass and
    accessed by name, not by a single-character switch.

4.  The processing stages are separate methods with clear return types:
      identify()       → str (format code) or raises UnrecognisedFormatError
      validate()       → FooterResult (VALID / CHECKSUM_MISMATCH / INVALID)
      harvest_ack()    → None (populates self.ack if ACK file)
      render_lines()   → list[str]  (convert + return output lines)

5.  render_lines() is pure for a given set of arguments.  It can be
    called multiple times (for multiple route destinations) without
    side effects.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Optional

from .checksum import ChecksumAccumulator
from .converter import FormatConverter
from . import record as R
from .exceptions import (
    FileNotReadableError, UnrecognisedFormatError,
    BadFooterError, BadChecksumError,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FileHeader:
    """Immutable snapshot of the structured-file header fields."""
    file_type:   str = ""
    file_version: str = ""
    src_role:    str = ""
    src_part:    str = ""
    dst_role:    str = ""
    dst_part:    str = ""
    test_flag:   str = ""
    file_id:     str = ""


@dataclass
class AckRecord:
    """Parsed ACK body (9ZY / 9ZZ records)."""
    serial:      str = ""
    success:     str = ""
    error_code:  str = ""
    error_text:  str = ""
    description: str = ""


class FooterResult(Enum):
    VALID            = auto()
    CHECKSUM_MISMATCH = auto()   # can be force-routed
    INVALID          = auto()    # fatal for this file


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class StructuredFile:
    """
    Represents one input file loaded from disk.

    Lifecycle::

        sf = StructuredFile.load("/path/to/file")  # may raise FileNotReadableError
        fmt = sf.identify()                         # may raise UnrecognisedFormatError
        result = sf.validate()                      # may raise BadFooterError
        sf.harvest_ack()                            # no-op if not an ACK file
        lines = sf.render_lines(dst_fmt, ...)       # get converted output lines
    """

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    def __init__(self, path: str, lines: list[str]) -> None:
        self._path   = path
        self._lines  = lines          # normalised, non-empty lines
        self._fmt: str = ""
        self.header  = FileHeader()
        self.ack: Optional[AckRecord] = None

    @classmethod
    def load(cls, path: str) -> "StructuredFile":
        """
        Read *path* from disk and return a :class:`StructuredFile`.

        Raises :class:`FileNotReadableError` if the file cannot be opened.
        """
        try:
            raw = Path(path).read_text(encoding="latin-1", errors="replace")
        except OSError as exc:
            raise FileNotReadableError(f"Cannot read {path}: {exc}") from exc

        lines = [
            ln.rstrip()
            for ln in raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")
            if ln.strip()
        ]
        return cls(path, lines)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def path(self) -> str:
        return self._path

    @property
    def filename(self) -> str:
        return Path(self._path).name

    @property
    def fmt(self) -> str:
        """Format code after :meth:`identify` has been called."""
        return self._fmt

    # ------------------------------------------------------------------
    # Stage 1 — Identify
    # ------------------------------------------------------------------

    def identify(self) -> str:
        """
        Examine the first record and determine the file format.

        Returns the format code ('U', 'P', or 'T').
        Raises :class:`UnrecognisedFormatError` if the header is unknown.
        """
        if not self._lines:
            raise UnrecognisedFormatError(f"Empty file: {self._path}")

        first = self._lines[0]

        if first.startswith("ZHV"):
            self._fmt = "U"
        elif first.startswith("ZHD"):
            pipes = R.count_pipes(first)
            if pipes == 11:
                self._fmt = "T"
            elif pipes == 6:
                self._fmt = "P"
            else:
                raise UnrecognisedFormatError(
                    f"ZHD with unexpected delimiter count ({pipes}) in {self._path}"
                )
        elif first.startswith("ZHF"):
            raise UnrecognisedFormatError(
                f"Fixed format (ZHF) is not supported: {self._path}"
            )
        else:
            raise UnrecognisedFormatError(
                f"Unrecognised header {first[:3]!r} in {self._path}"
            )

        log.debug("Identified %s as format %s", self._path, self._fmt)
        return self._fmt

    # ------------------------------------------------------------------
    # Stage 2 — Validate footer
    # ------------------------------------------------------------------

    def validate(self) -> FooterResult:
        """
        Validate the ZPT footer line-count and checksum.

        Returns a :class:`FooterResult` value.
        Raises :class:`BadFooterError` on structural problems (missing
        footer, bad line count).  A checksum mismatch returns
        ``FooterResult.CHECKSUM_MISMATCH`` rather than raising, so the
        caller can decide to force-route the file.
        """
        csum = ChecksumAccumulator()
        line_count = 0

        # Converter used only to translate to Pool format for checksumming.
        # A fresh instance is used here so it does not affect header state.
        to_pool = FormatConverter(self._fmt, "P")

        for i, line in enumerate(self._lines):
            pool_line = to_pool.convert_line(line)

            if i == 0:
                # Parse header parameters from the Pool representation
                if pool_line.startswith("ZHD"):
                    u_line = FormatConverter(self._fmt, "U").convert_line(line)
                    self._parse_header(u_line)
                csum.add(pool_line)
                continue

            if line.startswith("ZPT"):
                line_count -= 1   # header + footer are not counted
                result = self._check_footer_record(line, line_count, csum.value)
                return result

            line_count += 1
            csum.add(pool_line)

        raise BadFooterError(f"No ZPT footer found in {self._path}")

    def _parse_header(self, u_line: str) -> None:
        """Populate self.header from a User-format header line."""
        if not u_line.startswith("ZHV"):
            return
        s = R.parse(u_line)
        self.header = FileHeader(
            file_id      = R.seg(s, 1),
            file_type    = R.seg(s, 2)[:5],
            file_version = R.seg(s, 2)[5:],
            src_role     = R.seg(s, 3),
            src_part     = R.seg(s, 4),
            dst_role     = R.seg(s, 5),
            dst_part     = R.seg(s, 6),
            test_flag    = R.seg(s, 11),
        )

    def _check_footer_record(
        self, line: str, line_count: int, computed_csum: int
    ) -> FooterResult:
        s = R.parse(line)

        if self._fmt in ("P", "T"):
            if R.count_pipes(line) != 2:
                raise BadFooterError(
                    f"P/T footer has wrong delimiter count in {self._path}"
                )
            if not R.is_numeric(R.seg(s, 1)):
                raise BadFooterError(
                    f"Non-numeric line count in P/T footer: {self._path}"
                )
            file_lc = int(R.seg(s, 1))
            if file_lc != line_count + 2:
                raise BadFooterError(
                    f"Line count mismatch in {self._path}: "
                    f"footer says {file_lc}, computed {line_count + 2}"
                )
            file_csum = int(R.seg(s, 2) or "0")
            if file_csum != computed_csum:
                log.warning("Checksum mismatch in %s", self._path)
                return FooterResult.CHECKSUM_MISMATCH
            return FooterResult.VALID

        elif self._fmt == "U":
            if R.count_pipes(line) != 6:
                raise BadFooterError(
                    f"U footer has wrong delimiter count in {self._path}"
                )
            if not R.is_numeric(R.seg(s, 2)):
                raise BadFooterError(
                    f"Non-numeric line count in U footer: {self._path}"
                )
            file_lc = int(R.seg(s, 2))
            if file_lc != line_count:
                raise BadFooterError(
                    f"Line count mismatch in {self._path}: "
                    f"footer says {file_lc}, computed {line_count}"
                )
            csum_str = R.seg(s, 3)
            if not csum_str:
                log.info("Null checksum in %s (accepted)", self._path)
                return FooterResult.VALID
            if int(csum_str) != computed_csum:
                log.warning("Checksum mismatch in %s", self._path)
                return FooterResult.CHECKSUM_MISMATCH
            return FooterResult.VALID

        raise BadFooterError(f"Unexpected format {self._fmt!r} in footer check")

    # ------------------------------------------------------------------
    # Stage 3 — Harvest ACK data
    # ------------------------------------------------------------------

    _ACK_ERRORS: dict[str, str] = {
        "0":  "User File Delivered",
        "10": "Failed to Translate User File",
        "20": "Failed to Encrypt User File",
        "30": "Failed to Address Network File",
        "40": "Failed to Queue Network File",
        "50": "Failed to Send Network File",
        "60": "Failed to Acknowledge Network File",
    }

    def harvest_ack(self) -> None:
        """
        If this is an ACK file (type A0001 ver 001), scan the body for
        9ZY / 9ZZ records and populate :attr:`ack`.
        """
        if self.header.file_type != "A0001" or self.header.file_version != "001":
            return

        ack = AckRecord()
        for line in self._lines:
            if line.startswith("9ZY"):
                s = R.parse(line)
                ack.serial  = R.seg(s, 3)
                ack.success = R.seg(s, 4)
            elif line.startswith("9ZZ"):
                s = R.parse(line)
                ack.error_code  = R.seg(s, 3)
                ack.description = R.seg(s, 4)
                ack.error_text  = self._ACK_ERRORS.get(
                    ack.error_code, f"Unknown code -{ack.error_code}-"
                )
        self.ack = ack

    # ------------------------------------------------------------------
    # Stage 4 — Render output lines
    # ------------------------------------------------------------------

    def render_lines(
        self,
        dst_fmt: str,
        req_file_id: str = "",
        req_tflag: str = "",
        force_csum: bool = False,
    ) -> list[str]:
        """
        Convert all records to *dst_fmt* and return them as a list of
        strings (no trailing newlines).

        This method is *idempotent*: calling it multiple times with the
        same arguments produces the same output (important when a file
        matches multiple routing entries).

        Parameters
        ----------
        dst_fmt      : target format ('U', 'P', or 'T')
        req_file_id  : file-ID to embed when promoting from Pool format
        req_tflag    : test flag to embed in the new header
        force_csum   : True → write checksum even if original was null
        """
        converter = FormatConverter(self._fmt, dst_fmt)

        # Pass 1: build output lines and compute checksum over pool-format lines.
        # We need the final checksum to write into the ZPT footer, so we do
        # two passes: first compute the checksum, then rewrite the ZPT line.

        csum = ChecksumAccumulator()
        to_pool = FormatConverter(self._fmt, "P")

        for line in self._lines:
            if not line.startswith("ZPT"):
                csum.add(to_pool.convert_line(line, req_file_id=req_file_id))

        # Pass 2: convert with the now-known checksum.
        out: list[str] = []
        for line in self._lines:
            converted = converter.convert_line(
                line,
                req_file_id = req_file_id,
                req_csum    = csum.value_str,
                force_csum  = force_csum,
                req_tflag   = req_tflag,
            )
            out.append(converted)

        return out
